
easyDataset


A Python module to make interacting with SQL databases easier and faster, a wrapper for other alternatives
